<?php

	require 'pronerd-3.0.0.php';
	$databaseName="mkdevhub_caracal_db";
	$password="123";
	$user="root";
	$host="localhost";
	$database=new database($host,$user,$password,$databaseName);
	$database->set($host,$user,$password,$databaseName);
	$db=$database->connect();
	
?>